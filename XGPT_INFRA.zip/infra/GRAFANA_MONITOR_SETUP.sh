#!/bin/bash
# GRAFANA SETUP SCRIPT
echo "🚀 Setting up Grafana Monitoring..."
